package bank.jms;

public interface TaxServiceJMSSender {
    public void sendDepositJMSMessage(String s);
}
