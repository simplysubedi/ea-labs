package bank.event;

public class MailEvent {
    public MailEvent() {
    }
}
